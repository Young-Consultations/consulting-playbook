"""CLI package for Slugger."""
