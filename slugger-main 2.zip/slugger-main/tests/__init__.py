"""Test package for Slugger."""
